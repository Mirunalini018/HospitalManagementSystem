package boot.repo;

import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import boot.entity.Patient;
import boot.entity.Rep;

public interface PatientRepo extends JpaRepository<Patient, Long> {
    // Optional<Rep> findByEmailAndPassword(String email, String password);
//      @Query(value="select*from patient where email=:email",nativeQuery = true)
//	 Patient findByEmailAndPassword(@Param("email")  String email); 

	Optional<Patient> findByEmailAndPassword(String email,String password);
	Patient findByEmail(String email);
	 
}
